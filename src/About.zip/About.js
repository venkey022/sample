import React from "react";


const About = () => {
  return (
    // ****************line 1
    <div>
      <div className="about-head text-center">

        <h1 className="about-H1-main-page">About us</h1>
        <p1 className="about-p"><a href="url">Home</a>||about</p1>
      </div>


      <div className="container-fluid">

        <div className='row mt-5 mb-5'>
          <div className="col-md-1"></div>
          <div className='col-md-5'>
            <img className='about-image img-fluid' src='./images/home1.jpg' width='500px' height='300px' alt='pic' />
          </div>
          <div className='col-md-5  mt-3'>
            <span className="who" >---WHO WE ARE</span>
            <h1 className='mt-4 about-text'>More than 23+ years we <br />provide IT solutions</h1>
            <p className='mt-5 about-para'>Sed ut perspiciatis unde omnis iste natus errorsit voluptatem accusantium doloremque laudantium totam rem aperiam eaque ipsa quae ab illo invetore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.

              Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem</p>
            <button type="button" class="btn btn-primary">LEARNMORE<i class="bi bi-arrow-right"></i></button>
          </div>
          <div className="col-md-1"></div>


        </div>
      </div>



{/* row2 ---------------------------------------------------------------------------------------------*/}


      <div className="homecontainer">
        <div className="parent-div bg-danger d-flex align-items-center justifycontent-center">
          <div className="child-div bg-warning">

          </div>

        </div>

      </div>
      <div className="container">
        <div className="row justify-content-center mt-5 mb-6">

          <div className="col-md-4 shadow col-10 mb-3 ">
            <div className="card-body">
              <div className="text-center"> <img src="https://torun-react.vercel.app/assets/img/icon/icon-01.png"/></div>
              <h5 className="card-title text-center card-name mt-4">Web Development</h5>
              <p className="card-text text-center">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
              <div className="text-center mt-5 mb-5"> <button type="button" className="btn btn-outline-primary">READ MORE<i class="bi bi-arrow-right"></i></button></div>

            </div>
          </div>


          <div className="col-md-4 shadow col-10 mb-3 ">
            <div className="card-body">
              <div className="text-center"><img src="https://torun-react.vercel.app/assets/img/icon/icon-2.png"/> </div>
              <h5 className="card-title  text-center card-name mt-4">Database Analysis</h5>
              <p className="card-text text-center">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
              <div className="text-center mt-5 mb-5"> <button type="button" className="btn btn-outline-primary">READ MORE<i class="bi bi-arrow-right"></i></button></div>
            </div>
          </div>


          <div className="col-md-4 shadow col-10 mb-3" >
            <div className="card-body">
              <div className="text-center"> <img src="https://torun-react.vercel.app/assets/img/icon/icon-3.png"/></div>
              <h5 className="card-title text-center card-name mt-4">Server Security</h5>
              <p className="card-text text-center ">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
              <div className="text-center mt-5 mb-5"><button type="button" className="btn btn-outline-primary">READ MORE<i class="bi bi-arrow-right"></i></button></div>
            </div>
          </div>
        </div>
      </div>


{/* 3rd row-------------------------------------------------------------------------------- */}

      <div className="bg">
  
        <div className="container-fluid">
          <div className="about-h1 row">
            <div className="col-md-2"></div>

            <div className="col-md-8">
              <div className="row  bg-light">
                <div className="col-md-6 pt-5 pb-5">
                  <p>WHY CHOOSE US</p>
                  <h1 className="mb-5">We Are Expert In IT <br />Solutions Services</h1>
                  <h3>Best Ity solutions Provider Agency</h3>
                  <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium mque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi artecto beatae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas aspernatur aut odit aut fugit</p>
                  <h3>Professional & Experienced Team Member</h3>
                  <p>Sed ut perspiciatis unde omnis iste natus </p>
                </div>
                <div className="col-md-6 pt-5 pb-5">
                  <p >On the other hand we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment so blinded by desire that they cannot foresee the pain and trouble that are bound to ensue and equal blame belongs to those who fail in their duty through weakness of will which is the same as saying through shrinking from toil and pain cases are perfectly

                  </p>
                  <img className="img-fluid" src="https://torun-react.vercel.app/assets/img/bg/c.jpg" />
                </div>

              </div>
            </div>


            <div className="col-md-2"></div>

          </div>
        </div>

      </div>
     
{/* .......................... */}
<div className="container">
  <div className="row mt-5 mb-5">
    <div className="col-md-6">
      <h5 className="text-primary">-- OUR TEAM</h5>
      <h1 className="meet">Meet Experience<br/> Team Member</h1>
    </div>

    <div className="col-md-6">
      <p >But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give.</p>
      <button type="button" className=" mt-4 btn btn-primary nav-items">Join with us <i class="bi bi-arrow-right-short h-2"></i></button>
    </div>
  </div>
</div>

      {/* it is ceo----------------------------------------------------------------------------------------------------------- */}




      <div className="container">
        <div className="row justify-content-center mt-5 mb-3">

          <div className="col-sm-3 col-10 pb-3 mb-3 radius shadow">
            <div className="card-body">
              <img className="about1-image img-fluid" src="./images/solvina d naliz.jpg" alt="pic" />
              <h5 className="card-title text-center card-name mt-4">solvina d nailz</h5>
              <p className="card-text text-center">webdeveloper</p>
              <ul className="abouticons lit-inline txt-center">
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm  txt-center" ><i class="bi bi-facebook"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-twitter"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-instagram"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-youtube"></i></a>
                </li>
              </ul>
            </div>
          </div>




          <div className="col-sm-3  col-10 pb-3 mb-3 radius shadow">
            <div className="card-body">
              <img className="about1-image img-fluid" src="./images/jerry D.silva.jpg" alt="pic" />
              <h5 className="card-title  text-center card-name mt-4">jerry D.silva</h5>
              <p className="card-text text-center">ui designer</p>
              <ul className="abouticons lit-inline txt-center">
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm  txt-center" ><i class="bi bi-facebook"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-twitter"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-instagram"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-youtube"></i></a>
                </li>
              </ul>

            </div>
          </div>




          <div className="col-sm-3  col-10 pb-3 mb-3 radius shadow" >
            <div className="card-body">
              <img className="about1-image img-fluid" src="./images/David walillams.jpg" alt="pic" />
              <h5 className="card-title text-center card-name mt-4">David Willams</h5>
              <p className="card-text text-center">sr consultant</p>
              <ul className="abouticons lit-inline txt-center">
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm  txt-center" ><i class="bi bi-facebook"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-twitter"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-instagram"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-youtube"></i></a>
                </li>
              </ul>
            </div>
          </div>
          <div className="col-sm-3  col-10 pb-3  radius shadow">
            <div className="card-body">
              <img className="about1-image img-fluid" src="./images/michalz.jones.jpg" alt="pic" />
              <h5 className="card-title text-center card-name mt-4">michalz.jones</h5>
              <p className="card-text ">ceo&founder</p>

              <ul className="abouticons lit-inline txt-center">
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm  txt-center" ><i class="bi bi-facebook"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-twitter"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-instagram"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i class="bi bi-youtube"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

{/* 8th row--------------------------------------------------------------------------------------------------- ----------------- */}


      <div className="bg2 img-fluid">
<div className="container">
        <div className="row justify-content-center">

        <div className="col-md-6 pt-5">
        <h6 className="text text-light">DO YOU HAVE ANY PROJECT ?</h6>
        <h1 className="text text-light">Let’s Talk About Business Soluations With Us</h1>
        </div>
        <div className="col-md-6 pt-5">
<div className="d-flex">
        <button type="button" className="btn btn-light btn-lg . mr-5">contact us →</button>
  
<button type="button" className="btn btn-light btn-lg   ">join with us →</button>
</div>
        </div>
        </div>
</div>
      </div>


      <div className="container">
  <div className="row mt-5 mb-5">
    <div className="col-md-6">
      <span className="text-primary">-- OUR TESTIMONIALS</span>
      <h1 className="meet">More Than 800+ Customer<br/> Satisfied Our Solutions</h1>
    </div>

    <div className="col-md-6">
      
    </div>
  </div>
</div>
      {/* it i 9thpage  ...................................................................................... */}



      {/* it is 9th row------------------------------------------------------------------ */}

      <div className="container">
        <div className="row justify-content-center mt-5 mb-6">

          <div className="col-sm-4 shadow col-10 mb-3 ">
            <div className="card-body">
            <p className="card-text">It is a long established fact that a reader will be distracted by the readable content of a page when looking Software development services is your possibility to outsource software engineering and support, and get maintainable, secure and impactful software at the best price. To date, ScienceSoft has fulfilled 3,300+ projects and offers vast experience in different programming techs and software types. Request Software Development Services Our services</p>
            <ul className="abouticons lit-inline txt-center">
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm  txt-center" ><i className="star-bi bi-star-fill"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i className=" star-bi bi-star-fill"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i className="star-bi bi-star-fill"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i className="star-bi bi-star-fill"></i></a>
                </li>
              </ul>
              <ul class="list-unstyled">
  <li class="media">
    <img src="https://torun-react.vercel.app/assets/img/testimonial/01.png" class="mr-3" alt="..."/>
    <div class="media-body">
      <h5 class="mt-0 mb-1">List-based media object</h5>
      <p className="business">WEB DESIGNER</p>
    </div>
    </li>
</ul>
              
              
            </div>
          </div>


          <div className="col-sm-4 shadow col-10 mb-3 ">
            <div className="card-body">
              
              <p className="card-text">It is a long established fact that a reader will be distracted by the readable content of a page when looking Software development services is your possibility to outsource software engineering and support, and get maintainable, secure and impactful software at the best price. To date, ScienceSoft has fulfilled 3,300+ projects and offers vast experience in different programming techs and software types. Request Software Development Services Our services</p>
              <ul className="abouticons lit-inline txt-center">
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm  txt-center" ><i className="star-bi bi-star-fill"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i className=" star-bi bi-star-fill"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i className="star-bi bi-star-fill"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i className="star-bi bi-star-fill"></i></a>
                </li>
              </ul>
              <ul class="list-unstyled">
  <li class="media">
    <img src="https://torun-react.vercel.app/assets/img/testimonial/02.png" class="mr-3" alt="..."/>
    <div class="media-body">
      <h5 class="mt-0 mb-1">List-based media object</h5>
      <p className="business">SR CONSULTANT</p>
    </div>
    </li>
</ul>
              
            </div>
          </div>


          <div className="col-sm-4 shadow col-10 mb-3" >
            <div className="card-body">
              
              
              <p className="card-text">It is a long established fact that a reader will be distracted by the readable content of a page when looking Software development services is your possibility to outsource software engineering and support, and get maintainable, secure and impactful software at the best price. To date, ScienceSoft has fulfilled 3,300+ projects and offers vast experience in different programming techs and software types. Request Software Development Services Our services</p>
              <ul className="abouticons lit-inline txt-center">
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm  txt-center" ><i className="star-bi bi-star-fill"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i className=" star-bi bi-star-fill"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i className="star-bi bi-star-fill"></i></a>
                </li>
                <li className="list-inline-item">
                  <a href="#" class="btn-floating btn-sm " ><i className="star-bi bi-star-fill"></i></a>
                </li>
              </ul>
              <ul class="list-unstyled">
  <li className="media">
    <img  src="https://torun-react.vercel.app/assets/img/testimonial/03.png" class="mr-3" alt="..."/>
    <div class="media-body">
      <h5 class="mt-0 mb-1">List-based media object</h5>
      <p className="business">BUSINESS MANAGER</p>
    </div>
    </li>
</ul>


              
            </div>
          </div>
        </div>
      </div>

{/* it is last row------------------------------------------------------------------------------------- */}
<div className="continer">
<div className="row mt-5 mb-5 justify-content-center">
  <div className="col-md-1"></div>
  <div className="text-center   col-md-2 col-10"><img  src="https://torun-react.vercel.app/assets/img/brand/brand-01.png"/></div>
  <div className="text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-02.png"/></div>
  <div className=" text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-03.png"/></div>
  <div className=" text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-04.png"/></div>
  <div className=" text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-05.png"/></div>
  <div className="col-md-1"></div>
</div>
</div>
      

      
    
    </div>



  );
}

export default About;