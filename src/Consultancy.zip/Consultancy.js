import React from "react";

const Consultancy = () => {
    return (
    //  -----------------------first line
      <div>
        <div className="about-head text-center">
  
          <h1 className="consultancy-H1-main-page">Goals</h1>
          <p1 className="consultancy-p"><a href="url">Home </a> ||Goals</p1>
        </div>

        {/* 2nd line-------------------------------------------------------------- */}
        <div className="container">
  <div className="row">
    <div className="col-md-4 mt-4">
<img className="img-fluid" src="https://torun-react.vercel.app/assets/img/goals/01.jpg" alt="pic"/>
<h2 className="text mt-2">MIssion & Vision</h2>
<p className="text mt-2">Sedut perspiciatis unde omnis natus error voluptatem accusantium doloremque laudantium totam rem aperiam eaque</p>
    </div>
<div className="col-md-8 mt-4 ">
<img className="img-fluid" src="https://torun-react.vercel.app/assets/img/goals/02.jpg" alt="pic"/>
<h2 className="text mt-2">What DO We Want/ Our Goals</h2>
<p className="text mt-2">Must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give<br /> you a complete account of the system, and expound the actual teachings of the great explorer of the truth,  <br />the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because</p>
<p className="text mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium totam rem aperiam eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dictae.</p>

    </div>

  </div>
</div>


{/* 3rdline********************************* */}
        <div className="continer">
<div className="row mt-5 mb-5 justify-content-center">
  <div className="col-md-1"></div>
  <div className="text-center   col-md-2 col-10"><img  src="https://torun-react.vercel.app/assets/img/brand/brand-01.png" alt="pic "/></div>
  <div className="text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-02.png" alt="pic"/></div>
  <div className=" text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-03.png" alt="pic"/></div>
  <div className=" text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-04.png" alt="pic"/></div>
  <div className=" text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-05.png" alt="pic"/></div>
  <div className="col-md-1"></div>
</div>
</div>
{/* ....................... */}
<div className="container-fluid">
  <div className="row">
    <div className="col-md-6">
<img src="https://torun-react.vercel.app/assets/img/goals/03.jpg" alt="pic"/>
    </div>
<div className="col-md-6 bg-dark">
      <h6 className="text text-light pl-5 pt-5">--WHAT WE DO</h6>
      <h1 className="text text-light pl-5 pt-5">Super Quality IT  <br />Solutions Provide</h1>
      <p className="text  text-light pl-5 pt-5">But I must explain to you how all this mistaken idea of denoun cing <br />pleasure and praising pain was born and I will giv complete <br />account of the system, and expound the actual teachings of the<br /> great explorer of the truth the master-builder of</p>
      <p className="text text-light pl-5 pt-5"><i className="check bi bi-check"></i>Pleasure and praising pain was born and will complete</p>
      <p className="text text-light pl-5 pt-1"><i className=" check bi bi-check"></i>Pleasure and praising pain was born and will complete</p>
      <p className="text text-light pl-5 pt-1"><i className=" check bi bi-check"></i>Pleasure and praising pain was born and will complete</p>
      <button type="button" className="btn btn-primary btn-lg  text-cnter ">Learn more →</button>
    </div>

  </div>
</div>


        {/* 4th line************************************** */}





        <div className="container">
        <div className="row justify-content-center mt-5 mb-6">

          <div className="col-md-4 shadow col-10 mb-3 ">
            <div className="card-body">
              <div className="text-center"> <img src="https://torun-react.vercel.app/assets/img/icon/icon-01.png" alt="pic"/></div>
              <h5 className="card-title text-center card-name mt-4">Web Development</h5>
              <p className="card-text text-center">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
              <div className="text-center mt-5 mb-5"> <button type="button" className="btn btn-outline-primary">READ MORE<i class="bi bi-arrow-right"></i></button></div>

            </div>
          </div>


          <div className="col-md-4 shadow col-10 mb-3 ">
            <div className="card-body">
              <div className="text-center"><img src="https://torun-react.vercel.app/assets/img/icon/icon-2.png" alt="pic"/> </div>
              <h5 className="card-title  text-center card-name mt-4">Database Analysis</h5>
              <p className="card-text text-center">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
              <div className="text-center mt-5 mb-5"> <button type="button" className="btn btn-outline-primary">READ MORE<i class="bi bi-arrow-right"></i></button></div>
            </div>
          </div>


          <div className="col-md-4 shadow col-10 mb-3" >
            <div className="card-body">
              <div className="text-center"> <img src="https://torun-react.vercel.app/assets/img/icon/icon-3.png" alt="pic"/></div>
              <h5 className="card-title text-center card-name mt-4">Server Security</h5>
              <p className="card-text text-center ">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
              <div className="text-center mt-5 mb-5"><button type="button" className="btn btn-outline-primary">READ MORE<i class="bi bi-arrow-right"></i></button></div>
            </div>
          </div>
        </div>
      </div>
      <div className="container">
        <div className="row justify-content-center mt-5 mb-6">

          <div className="col-md-4 shadow col-10 mb-3 ">
            <div className="card-body">
              <div className="text-center"> <img src="https://torun-react.vercel.app/assets/img/icon/icon-4.png" alt="pic"/></div>
              <h5 className="card-title text-center card-name mt-4">UX/UI Strategy</h5>
              <p className="card-text text-center">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
              <div className="text-center mt-5 mb-5"> <button type="button" className="btn btn-outline-primary">READ MORE<i class="bi bi-arrow-right"></i></button></div>

            </div>
          </div>


          <div className="col-md-4 shadow col-10 mb-3 ">
            <div className="card-body">
              <div className="text-center"><img src="https://torun-react.vercel.app/assets/img/icon/icon-5.png" alt="pic"/> </div>
              <h5 className="card-title  text-center card-name mt-4">Analysis For Tools</h5>
             
              <p className="card-text text-center">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
              <div className="text-center mt-5 mb-5"> <button type="button" className="btn btn-outline-primary">READ MORE<i class="bi bi-arrow-right"></i></button></div>
            </div>
          </div>


          <div className="col-md-4 shadow col-10 mb-3" >
            <div className="card-body">
              <div className="text-center"> <img src="https://torun-react.vercel.app/assets/img/icon/icon-6.png" alt="pic"/></div>
              <h5 className="card-title text-center card-name mt-4">Marketing Strategy</h5>
              <p className="card-text text-center ">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
              <div className="text-center mt-5 mb-5"><button type="button" className="btn btn-outline-primary">READ MORE<i class="bi bi-arrow-right"></i></button></div>
            </div>
          </div>
        </div>
      </div>
      {/* 6thline********************************* */}
      <div className="bg2 img-fluid">
<div className="container">
        <div className="row justify-content-center">

        <div className="col-md-6 pt-5">
        <h6 className="text text-light">DO YOU HAVE ANY PROJECT ?</h6>
        <h1 className="text text-light">Let’s Talk About Business Soluations With Us</h1>
        </div>
        <div className="col-md-6 pt-5">
<div className="d-flex">
        <button type="button" className="btn btn-light btn-lg . mr-5">contact us →</button>
  
<button type="button" className="btn btn-light btn-lg   ">join with us →</button>
</div>
        </div>
        </div>
</div>
      </div>
      {/* 8thline***************************************** */}
      <div className="continer">
<div className="row mt-5 mb-5 justify-content-center">
  <div className="col-md-1"></div>
  <div className="text-center   col-md-2 col-10"><img  src="https://torun-react.vercel.app/assets/img/brand/brand-01.png" alt="pic "/></div>
  <div className="text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-02.png" alt="pic"/></div>
  <div className=" text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-03.png" alt="pic"/></div>
  <div className=" text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-04.png" alt="pic"/></div>
  <div className=" text-center col-md-2 col-10"><img src="https://torun-react.vercel.app/assets/img/brand/brand-05.png" alt="pic"/></div>
  <div className="col-md-1"></div>
</div>
</div>
        </div>
      
      
       
        
  );
}

export default Consultancy


