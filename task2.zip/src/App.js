import React from 'react'
import About from './About'
import './App.css'

function App() {
  return (
    <div>
      <About/>
    </div>
  )
}

export default App