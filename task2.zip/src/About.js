import React from "react";


const About = () =>{
    return (
        <div>
        <div className="about-head text-center">
            
                <h1 className="about-H1-main-page">About us</h1>
                <p1 className="p"><a href="url">Home</a>||about</p1>
            </div>
          
           <div className='row mt-5 mb-5'>
            <div className="col-md-1"></div>
                    <div className='col-lg-5'>
                        <img className='about-image' src='./images/home1.jpg' width='500px' height='300px' alt='pic' />
                    </div>
                    <div className='col-md-5 mt-3'>
                       <span className="who" >---WHO WE ARE</span>
                        <h1 className='mt-4 about-text'>More than 23+ years we <br/>provide IT solutions</h1>
                        <p className='mt-5 about-para'>Sed ut perspiciatis unde omnis iste natus errorsit voluptatem accusantium doloremque laudantium totam rem aperiam eaque ipsa quae ab illo invetore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.

                   Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem</p>
                   <button type="button" class="btn btn-primary">LEARNMORE<i class="bi bi-arrow-right"></i></button>
                    </div>
                    
                    <div className="col-md-1"></div>

                </div> 
                <div className="container">
                  <div className="row mb-5">

                    <div className="col-sm-4 radius shadow">
                      <div className="card-body">
                        <div className="text-center"> <i className="bi bi-laptop  "></i></div>
                        <h5 className="card-title text-center card-name mt-4">Web Development</h5>
                        <p className="card-text text-center">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
                        <div className="text-center mt-4"> <button type="button" className="btn btn-primary ">LEARNMORE<i class="bi bi-arrow-right"></i></button></div>
                       
                      </div>
                    </div>


                    <div className="col-sm-4 radius shadow">
                      <div className="card-body">
                      <div className="text-center"><i className="bi bi-laptop  "></i> </div>
                        <h5 className="card-title  text-center card-name mt-4">Database Analysis</h5>
                        <p className="card-text">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
                        <div className="text-center mt-4"> <button type="button" className="btn btn-primary ">LEARNMORE<i class="bi bi-arrow-right"></i></button></div>
                      </div>
                    </div>


                    <div className="col-sm-4 radius shadow" >
                      <div className="card-body">
                      <div className="text-center"> <i className="bi bi-laptop  "></i></div>
                        <h5 className="card-title text-center card-name mt-4">Server Security</h5>
                        <p className="card-text">It is a long established fact that a reader will be distracted by the readable content of a page when looking</p>
                        <div className="text-center mt-4"> <button type="button" className="btn btn-primary ">LEARNMORE<i class="bi bi-arrow-right"></i></button></div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="homecontainer">
                  <div className="parent-div bg-danger d-flex align-items-center justifycontent-center">
                    <div className="child-div bg-warning">

                  </div>

                </div>
                
</div>
             <div className="bg">
              <div className="text">
                <h1 className="h1">jhhjhj</h1>
                <p>
                  jgcvhjhbjkbjkjjbkbjk
                </p>

              </div>
          </div>
             <div className="container">
                  <div className="row mb-3">

                    <div className="col-sm-3 radius shadow">
                      <div className="card-body">
                      <img className="about1-image" src="./images/solvina d naliz.jpg" alt="pic"/>
                        <h5 className="card-title text-center card-name mt-4">solvina d nailz</h5>
                        <p className="card-text text-center">webdeveloper</p>
                        <ul className="abouticons lit-inline txt-center">
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm  txt-center" ><i class="bi bi-facebook"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-twitter"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-instagram"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-youtube"></i></a>
                          </li>
                        </ul>
                      </div>
                    </div>


                    <div className="col-sm-3 radius shadow">
                      <div className="card-body">
                      <img className="about1-image" src="./images/jerry D.silva.jpg" alt="pic"/>
                        <h5 className="card-title  text-center card-name mt-4">jerry D.silva</h5>
                        <p className="card-text text-center">ui designer</p>
                        <ul className="abouticons lit-inline txt-center">
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm  txt-center" ><i class="bi bi-facebook"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-twitter"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-instagram"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-youtube"></i></a>
                          </li>
                        </ul>
                      
                      </div>
                    </div>


                    <div className="col-sm-3 radius shadow" >
                      <div className="card-body">
                      <img className="about1-image" src="./images/David walillams.jpg" alt="pic"/>
                        <h5 className="card-title text-center card-name mt-4">David Willams</h5>
                        <p className="card-text text-center">sr consultant</p>
                        <ul className="abouticons lit-inline txt-center">
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm  txt-center" ><i class="bi bi-facebook"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-twitter"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-instagram"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-youtube"></i></a>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div className="col-sm-3 radius shadow">
                      <div className="card-body">
                      <img className="about1-image" src="./images/michalz.jones.jpg" alt="pic"/>
                        <h5 className="card-title text-center card-name mt-4">michalz.jones</h5>
                        <p className="card-text ">ceo&founder</p>
                        
                        <ul className="abouticons lit-inline txt-center">
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm  txt-center" ><i class="bi bi-facebook"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-twitter"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-instagram"></i></a>
                          </li>
                          <li className="list-inline-item">
                            <a href="#"class="btn-floating btn-sm " ><i class="bi bi-youtube"></i></a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
             
</div>

               

    );
}

export default About;